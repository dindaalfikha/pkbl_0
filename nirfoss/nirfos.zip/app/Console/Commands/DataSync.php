<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\MasterCSV;
use App\Models\CsvDB;
use App\Models\CsvToTable;
use File;

class DataSync extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'data:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $files = File::allFiles(storage_path() . '/file_csv/');
        foreach ($files as $key => $value) {
            $file = File::get($value);
            $filename = explode('/', $value);
            $filename = array_pop($filename);
            $table_name = explode('_', $filename);
            $table_name = str_replace(' ', '_', strtolower($table_name[0]));
            $file = fopen($value, "r");
            
            $check_exist = CsvToTable::where(['table_name' => $table_name])->first();

            if($check_exist) {
                $sql = "INSERT INTO `" . $table_name . "` ";
                $colSql = '(';
                $valSql = '(';
    
                $columnMaster = MasterCSV::get();
                $columnCustom = CsvDB::join('master_csv_to_table', 'csv_db_associate.id_table', '=', 'master_csv_to_table.id_table')->where(['master_csv_to_table.table_name' => $table_name])->get();
    
                while (($column = fgetcsv($file, 10000, ",")) !== false) {
                    $sql_check = "SELECT `date`, `time` FROM `" . $table_name . "` WHERE `date` = '" . date('Y-m-d', strtotime($column[25])) . "' AND `time` = '" . $column[26] . "'";
                    $sql_check = DB::select($sql_check);
                    if(!$sql_check) {
                        foreach ($columnMaster as $key => $value) {
                            if ($value->type === "DATE") {
                                $colSql .= " `" . $value->col_table_name . "`, ";
                                $valSql .= " '" . date('Y-m-d', strtotime($column[$value->col_csv_index])) . "', ";
                            } else if ($value->type === "DATETIME") {
                                $colSql .= " `" . $value->col_table_name . "`, ";
                                $valSql .= " '" . date('Y-m-d H:i:s', strtotime($column[$value->col_csv_index])) . "', ";
                            } else {
                                $colSql .= " `" . $value->col_table_name . "`, ";
                                $valSql .= " '" . $column[$value->col_csv_index] . "', ";
                            }
                        }
        
                        $count = $columnCustom->count();
                        foreach ($columnCustom as $key => $value) {
                            if (($count - 1) > $key) {
                                $colSql .= " `" . $value->table_col_name . "`, ";
                                $valSql .= " '" . $column[$value->csv_col_index] . "', ";
                            } else {
                                $colSql .= " `" . $value->table_col_name . "`) ";
                                $valSql .= " '" . $column[$value->csv_col_index] . "') ";
                            }
                        }
                    }
                }

                if(!$sql_check) {
                    DB::select($sql . $colSql . " VALUES " . $valSql);
                }
            }
            
        }
    }
}
